# -*- coding: UTF-8 -*-
import socket, os, struct
import time
from picamera import  PiCamera
import RPi.GPIO as GPIO

GPIO.setmode(GPIO.BCM)
IN = 12
GPIO.setup(IN, GPIO.IN)

"""set ip address"""
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect(('139.196.227.48', 23457))

"""set camera"""
camera = PiCamera()
camera.resolution = (1920,1080)
camera.framerate = 60
camera.vflip = True  

while True:
    while(GPIO.input(IN)):
        print("someone come in")
        camera.capture('images/0.jpg')
        filepath = 'images/0.jpg'
        if os.path.isfile(filepath):
            fileinfo_size = struct.calcsize('128sq')  # 定义打包规则
            # 定义文件头信息，包含文件名和文件大小
            fhead = struct.pack('128sq', os.path.basename(filepath).encode("utf-8"), os.stat(filepath).st_size)
            s.send(fhead)
            print('client filepath: ', os.path.basename(filepath), os.stat(filepath).st_size)
            fo = open(filepath, 'rb')
            while True:
                filedata = fo.read(1024)
                if not filedata:
                    break
                s.send(filedata)
            #time.sleep(0.5)
            fo.close()
            print('send over...')
        time.sleep(1)