import socketserver
import socket
import os
import time
import threading

import cv2
import numpy as np
from tensorflow_loader import load_tf_model
from utils.anchor_generator import generate_anchors
from tensorflow_infer import inference

event = threading.Event()
sess, graph = load_tf_model('face_mask_detection.pb')
# anchor configuration
feature_map_sizes = [[33, 33], [17, 17], [9, 9], [5, 5], [3, 3]]
anchor_sizes = [[0.04, 0.056], [0.08, 0.11], [0.16, 0.22], [0.32, 0.45], [0.64, 0.72]]
anchor_ratios = [[1, 0.62, 0.42]] * 5

# generate anchors
anchors = generate_anchors(feature_map_sizes, anchor_sizes, anchor_ratios)

# for inference , the batch size is 1, the model output shape is [1, N, 4],
# so we expand dim for anchors to [1, anchor_num, 4]
anchors_exp = np.expand_dims(anchors, axis=0)

id2class = {0: 'Mask', 1: 'NoMask'}




with open("count.txt",'r') as f:
    num = f.read()
    num=num.strip()
    f.close()

class MessageServer(threading.Thread):
    def __init__(self, host , port):
        threading.Thread.__init__(self)
        self.ADDR = (host, port)
        self.s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    def tcp_connect(self, conn, addr):
        global event
        print(' Connected by: ', addr)
        time.sleep(5)
        while True:
            #加入你的判定发送条件，比如识别成功才会发�?
            #在FileServer类中相应部分进行识别，当前部分仅仅发送报警信�?
            event.wait()
            s = "No Mask!"
            conn.send(s.encode())
            print('send success!')
            time.sleep(3)
            break
            event.clear()
        conn.close()

    def run(self):
        print('Message Service Start...')
        self.s.bind(self.ADDR)
        self.s.listen(5)
        conn, addr = self.s.accept()
        t = threading.Thread(target=self.tcp_connect, args=(conn, addr))
        t.start()
        self.s.close()    

class FileServer(threading.Thread):
    def __init__(self, host , port):
        threading.Thread.__init__(self)
        self.ADDR = (host, port)
        self.s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.first = r'./picture'
        os.chdir(self.first)                                     # first是初始路�?在linux系统中反斜杠需要修�?

    def tcp_connect(self, conn, addr):
        print(' Connected by: ', addr)
        
        while True:
            data = conn.recv(1024)
            data = data.decode()
            if data == 'quit':
                print('Disconnected from {0}'.format(addr))
                break
            order = data.split(' ')[0]                             # 获取相应命令
            self.recv_func(order, data, conn)
                
        conn.close()

    # 保存上传文件
    def Recv(self, message, conn):
        global num,event
        fileName = r'./' + num +".bmp"
        getmsg='getmsg'
        conn.send(getmsg.encode())
        with open(fileName, 'wb+') as f:
            while True:
                data = conn.recv(1024)
                if data == 'EOF'.encode():
                    f.close()
                    break
                f.write(data)
        print('receive ',fileName)

        with open(r'../count.txt','w') as fp:
            num = str(int(num) + 1)
            fp.write(num)
            fp.close()
        ###################################
        ########在此处嵌入识别的函数########
        ###################################
        img=cv2.imread(fileName)
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        rslt_path=r'./blacklist/'
        rslt=inference(img,rslt_path,sess, graph,feature_map_sizes,anchor_sizes,anchor_ratios,anchors,anchors_exp,id2class, show_result=True, target_shape=(260, 260))[0][0]
        print('result for',fileName,'is',rslt)
        if rslt:
            event.set()

    # 判断输入的命令并执行对应的函�?
    def recv_func(self, order, message, conn):
        if order == 'Upload':
            return self.Recv(message, conn)

    def Send(self, message, conn):
        name = message.split()[1]                               # 获取第二个参�?文件�?
        fileName = r'./test_origin/' + name
        with open(fileName, 'rb') as f:    
            while True:
                a = f.read(1024)
                if not a:
                    break
                conn.send(a)
        time.sleep(0.1)                                          # 延时确保文件发送完�?
        conn.send('EOF'.encode())

    #运行客户�?
    def run(self):
        print('File Service Start...')
        self.s.bind(self.ADDR)
        self.s.listen(5)
        while True:
            conn, addr = self.s.accept()
            t = threading.Thread(target=self.tcp_connect, args=(conn, addr))
            t.start()
        self.s.close()


if __name__ == "__main__":
    
    host = "172.19.255.208"
    port = 23456
    #FileServer = FileServer(host,port)
    MessageServer = MessageServer(host,port+1)
    #FileServer.start()
    MessageServer.start()
