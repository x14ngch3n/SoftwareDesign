import face_recognition
import os
import pymysql
import numpy as np

vector_path = "/home/zkx/new_server/vectors/"
register_path = "/home/zkx/new_server/register_pics/"
register_pics = os.listdir(register_path)
register_pics.sort()

conn = pymysql.connect(
    host='127.0.0.1',
    port=3306,
    user='root',
    password='123456',
    db='ListDb',
    charset='utf8'
)

cursor = conn.cursor()

for i, p in enumerate(register_pics):
    pic = register_path + p
    img = face_recognition.load_image_file(pic)
    encodings = face_recognition.face_encodings(img)
    if len(encodings) == 0:
        print('fail to recon ', pic)
        continue
    encoding = encodings[0]
    npy_path = vector_path + str(i) + '.npy'
    np.save(npy_path, encoding)
    sql = "insert into `anchor`(vecpath,imgpath) values(\"%s\",\"%s\")" % (npy_path, pic)
    print(i,sql)
    cursor.execute(sql)
    conn.commit()

conn.close()
