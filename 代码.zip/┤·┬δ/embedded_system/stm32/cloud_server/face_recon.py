import face_recognition
import pymysql
import os
import numpy as np
from shutil import move, copy2
from time import sleep

blacklist_fold = "/home/zkx/new_server/blacklist/"
recognized_fold = "/home/zkx/new_server/recognized/"
unrecognized_fold = "/home/zkx/new_server/unrecognized/"
show_fold = "/home/lty/epidemic/static/image/"
rshow_fold = "../static/image/"
# ebd_path = "/home/zkx/face_recon_test/ebd/"

conn = pymysql.connect(
    host='127.0.0.1',
    port=3306,
    user='root',
    password='123456',
    db='ListDb',
    charset='utf8'
)

cursor = conn.cursor()

conn1 = pymysql.connect(
    host='127.0.0.1',
    port=3306,
    user='root',
    password='123456',
    db='List',
    charset='utf8'
)

cursor1 = conn1.cursor()


def str2date(x):
    return x[:4] + '-' + x[4:6] + '-' + x[6:8], x[8:10] + ':' + x[10:12] + ':' + x[12:14]


def get_label(encoding, th):
    sql = 'select pid,vecpath from `anchor`'
    rownum = cursor.execute(sql)
    dmin = 100
    label = -1
    for r in range(rownum):
        cursor.scroll(r, mode='absolute')
        row = cursor.fetchone()
        anchor = np.load(row[1])
        d = face_recognition.face_distance([anchor], encoding)[0]
        print(row[0], d)
        if d < dmin:
            dmin = d
            label = row[0]
    if dmin < th:
        return label
    else:
        return -1


while True:
    sleep(1)
    black_pics = os.listdir(blacklist_fold)
    if len(black_pics) == 0:
        continue
    black_pics.sort()

    for pic in black_pics:
        img = face_recognition.load_image_file(blacklist_fold + pic)
        encodings = face_recognition.face_encodings(img)
        if len(encodings) == 0:
            continue
        encoding = encodings[0]
        label = get_label(encoding, 0.58)
        if label == -1:
            move(blacklist_fold + pic, unrecognized_fold + pic)
        else:
            date, time = str2date(pic.split('_')[0])
            location = pic.split('_')[1]
            picname = pic.split('.')[0] + '_p' + str(label) + '.jpg'
            dstpic = rshow_fold + picname
            copy2(blacklist_fold + pic, recognized_fold + picname)
            move(blacklist_fold + pic, show_fold + picname)
            sql = 'insert into Model_blacklist(pid,path,location,date,time) values(%s,\"%s\",\"%s\",\"%s\",\"%s\")' % (
            label, dstpic, location, date, time)
            print(sql)
            cursor1.execute(sql)
            conn1.commit()
