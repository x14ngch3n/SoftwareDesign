import face_recognition
import os
import numpy as np
import random
import pymysql

src = "/home/zkx/face_recon_test/LFW/lfw/"
ebd_path = "/home/zkx/face_recon_test/ebd/"
th_path = "/home/zkx/face_recon_test/threshold/"

conn = pymysql.connect(
    host='127.0.0.1',
    port=3306,
    user='root',
    password='',
    db='fr',
    charset='utf8'
)

cursor = conn.cursor()
inter = []

for person in range(4148):
    sql = "select ebdLoc from embedding where label=%s" % person
    rows = cursor.execute(sql)
    if rows > 0:
        r = random.randint(0, rows-1)
        #print(rows,r)
        cursor.scroll(r, mode='absolute')
        n1 = np.load(ebd_path+cursor.fetchone()[0])
    else:
        continue
    sql1 = "select ebdLoc from embedding where label>%s" % person
    rows1 = cursor.execute(sql1)
    if rows1 > 0:
        r = random.randint(0, rows1-1)
        cursor.scroll(r, mode='absolute')
        n2 = np.load(ebd_path+cursor.fetchone()[0])
        d = face_recognition.face_distance([n1], n2)
        print(person, d)
        inter.append(d[0])
np.save(th_path+'inter.npy', np.array(inter))
