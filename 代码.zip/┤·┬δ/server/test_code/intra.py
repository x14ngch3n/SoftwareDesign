import face_recognition
import os
import numpy as np
import random
import pymysql

src = "/home/zkx/face_recon_test/LFW/lfw/"
ebd_path = "/home/zkx/face_recon_test/ebd/"
th_path="/home/zkx/face_recon_test/threshold/"

conn = pymysql.connect(
    host='127.0.0.1',
    port=3306,
    user='root',
    password='',
    db='fr',
    charset='utf8'
)

cursor = conn.cursor()
intra=[]

for person in range(4149):
    sql = "select ebdLoc from embedding where label=%s" % person
    rows = cursor.execute(sql)
    if rows > 1:
        f1=cursor.fetchone()
        f2=cursor.fetchone()
        #print(f1)
        n1=np.load(ebd_path+f1[0])
        n2=np.load(ebd_path+f2[0])
        d = face_recognition.face_distance([n1], n2)
        print(person,d)
        intra.append(d[0])
np.save(th_path+'intra.npy',np.array(intra))