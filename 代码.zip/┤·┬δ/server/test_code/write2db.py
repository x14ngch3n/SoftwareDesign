import pymysql
import os
import numpy as np

src = "/home/zkx/face_recon_test/LFW/lfw/"
ebd_path = "/home/zkx/face_recon_test/ebd/"


conn=pymysql.connect(
    host='127.0.0.1',
    port=3306,
    user='root',
    password='',
    db='fr',
    charset='utf8'
)

cursor=conn.cursor()

for i,ebd in enumerate(os.listdir(ebd_path)):
    m=ebd.find('_')
    sql = 'insert into embedding values(%s,\'%s\',%s)' %(i,ebd,ebd[:m])
    row=cursor.execute(sql)
    if i%1000==0:
        print(i,row)

conn.commit()
cursor.close()
conn.close()