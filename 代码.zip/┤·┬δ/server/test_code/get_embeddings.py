import face_recognition
import os
import numpy as np

src="/home/zkx/face_recon_test/LFW/lfw/"
ebd_path="/home/zkx/face_recon_test/ebd/"

for i,fold in enumerate(os.listdir(src)):
    name=src+fold+'/'
    for j,pic in enumerate(os.listdir(name)):
        p=name+pic
        img=face_recognition.load_image_file(p)
        encoding=face_recognition.face_encodings(img)
        if len(encoding)==0:
            break;
        encoding=encoding[0]
        np.save(ebd_path+str(i)+'_'+str(j)+'.npy',encoding)
        print(str(i)+'_'+str(j)+'.npy')
