#th=0.62

import numpy as np
th_path="/home/zkx/face_recon_test/threshold/"

inter=np.load(th_path+'inter.npy')
intra=np.load(th_path+'intra.npy')

for mth in range(30,80):
    th=mth/float(100)
    far=sum([i<th for i in inter])/float(4148)
    frr=sum([i>th for i in intra])/float(4148)
    print(th,far,frr)