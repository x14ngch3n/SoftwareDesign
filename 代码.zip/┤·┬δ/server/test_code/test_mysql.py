import pymysql

conn=pymysql.connect(
    host='127.0.0.1',
    port=3306,
    user='root',
    password='',
    db='fr',
    charset='utf8'
)

cursor=conn.cursor()
 
# 执行sql语句
sql = '''
select 
'''

rows=cursor.execute(sql)  # 返回结果是受影响的行数
print(rows)

conn.close()