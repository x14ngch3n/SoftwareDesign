# Test Code

项目运行时不需要此部分代码，此部分代码的作用是测试与数据库的连接以及验证人脸识别模型，确定最终判别是否是同一个人的距离的阈值。

- get_embeddings.py：得到LFW数据集4148人的嵌入，存入ebd/。
- test_mysql.py：测试连接数据库。
- write2db.py：将ebd/中的嵌入写入数据库。
- inter.py：得到4124个类间距离。
- intra.py：得到1204个类内距离。
- set_th.py：得到FAR=0.1FRR时的阈值。结果：threshold=0.58, FAR=0.46%, FRR=4.3%。

