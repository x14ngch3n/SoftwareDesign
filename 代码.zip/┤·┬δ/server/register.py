import face_recognition
import os
import pymysql
import numpy as np

cur_path = os.getcwd()

vector_path = cur_path + "/vectors/"  # 存放人脸特征向量
register_path = cur_path + "/register_pics/"  # 存放注册的人脸
register_pics = os.listdir(register_path)
register_pics.sort()

# 连接数据库
conn = pymysql.connect(
    host='127.0.0.1',
    port=3306,
    user='root',
    password='123456',
    db='ListDb',
    charset='utf8'
)

cursor = conn.cursor()

for i, p in enumerate(register_pics):
    pic = register_path + p
    img = face_recognition.load_image_file(pic)
    encodings = face_recognition.face_encodings(img)  # 获得人脸特征
    if len(encodings) == 0:
        print('fail to recon ', pic)
        continue
    encoding = encodings[0]
    npy_path = vector_path + str(i) + '.npy'
    np.save(npy_path, encoding)  # 以128位向量（npy格式）保存至vector/中
    sql = "insert into `anchor`(vecpath,imgpath) values(\"%s\",\"%s\")" % (npy_path, pic)  # 写入ListDb的anchor表中
    print(i, sql)
    cursor.execute(sql)
    conn.commit()

conn.close()
