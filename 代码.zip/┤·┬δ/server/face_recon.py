import face_recognition
import pymysql
import os
import numpy as np
from shutil import move, copy2
from time import sleep

cur_path = os.getcwd()

blacklist_fold = cur_path + "/blacklist/"  # 黑名单，充当待处理图片队列
recognized_fold = cur_path + "/recognized/"  # 在特征库中有匹配的人脸
unrecognized_fold = cur_path + "/unrecognized/"  # 未识别成功的人脸（在特征库中没有匹配的人脸）
show_fold = "/home/lty/epidemic/static/image/"  # 这里是对应的Django框架文件夹
rshow_fold = "../static/image/"

# 连接ListDb数据库（存储着注册过的人脸特征）
conn = pymysql.connect(
    host='127.0.0.1',
    port=3306,
    user='root',
    password='123456',
    db='ListDb',
    charset='utf8'
)

cursor = conn.cursor()

# 连接List数据库（存储着对于未戴口罩事件的登记）
conn1 = pymysql.connect(
    host='127.0.0.1',
    port=3306,
    user='root',
    password='123456',
    db='List',
    charset='utf8'
)

cursor1 = conn1.cursor()


# 从嵌入式设备传来照片名中提取出日期时间
def str2date(x):
    return x[:4] + '-' + x[4:6] + '-' + x[6:8], x[8:10] + ':' + x[10:12] + ':' + x[12:14]


# 输入编码和阈值，找出特征库中距离最近的是谁，输出-1代表没有匹配
def get_label(encoding, th):
    sql = 'select pid,vecpath from `anchor`'
    rownum = cursor.execute(sql)
    dmin = 100
    label = -1
    for r in range(rownum):
        cursor.scroll(r, mode='absolute')
        row = cursor.fetchone()
        anchor = np.load(row[1])
        d = face_recognition.face_distance([anchor], encoding)[0]  # 获得距离
        print(row[0], d)
        if d < dmin:
            dmin = d
            label = row[0]
    if dmin < th:
        return label
    else:
        return -1


# 循环不停地运行，若没有照片，则休眠1秒
while True:
    sleep(1)
    black_pics = os.listdir(blacklist_fold)
    if len(black_pics) == 0:
        continue
    black_pics.sort()

    for pic in black_pics:
        img = face_recognition.load_image_file(blacklist_fold + pic)
        encodings = face_recognition.face_encodings(img)
        if len(encodings) == 0:
            continue
        encoding = encodings[0]
        label = get_label(encoding, 0.58)
        if label == -1:  # 若未识别出，将图片移至unrecognized/
            move(blacklist_fold + pic, unrecognized_fold + pic)
        else:  # 识别出
            date, time = str2date(pic.split('_')[0])
            location = pic.split('_')[1]
            picname = pic.split('.')[0] + '_p' + str(label) + '.jpg'  # p后面表示识别结果label
            dstpic = rshow_fold + picname
            copy2(blacklist_fold + pic, recognized_fold + picname)  # 复制到recognized/
            move(blacklist_fold + pic, show_fold + picname)  # 移至前端展示所需的图片资源文件夹，等待公示
            sql = 'insert into Model_blacklist(pid,path,location,date,time) values(%s,\"%s\",\"%s\",\"%s\",\"%s\")' % (
                label, dstpic, location, date, time)  # 将未戴口罩的事件写入List数据库的Model_blacklist表
            print(sql)
            cursor1.execute(sql)
            conn1.commit()
