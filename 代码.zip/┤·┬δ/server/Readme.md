# Server

本文件夹用于服务器端实现算法，包含口罩识别和人脸识别两个模块。

- blacklist/：存储裁剪过的未戴口罩的人脸图片。
- recognized/：存储识别成功的未戴口罩人脸图片。
- uncognized/：存储未识别成功的未戴口罩人脸图片。
- register_pics/：存储系统内所有人的一张注册人脸照。
- test_origin/：存储树莓派拍照传来并依据时间、地点重命名的照片。
- vectors/：存储系统内所有人的人脸特征嵌入（128维特征向量，npy格式）。
- test_code/：测试代码，用于验证模型与测试连接数据库，不运行。
- utils/：口罩识别模块的工具代码，用于实现人脸检测。
- face_mask_detection.pb：口罩检测的模型。
- face_recon.py：人脸识别模块入口。
- mask_detect：口罩识别模块入口，也包括与拍照和报警的嵌入式设备通信。
- tensorflow_infer: 定义inference函数，用于口罩识别。
- tensorflow_loader: 载入模型。
- tfmodel.py：定义模型，不运行。

