# -*- coding: utf-8 -*- 
import random
import json
import datetime
import django
import os
if not os.environ.get('DJANGO_SETTINGS_MODULE'):
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'epidemic.settings')
django.setup()
from Model.models import blacklist
from django.shortcuts import render
from django.http import HttpResponse
from django.http import JsonResponse
import epidemic.utils.FileProcess as FP

class DateEncoder(json.JSONEncoder):  #重写json类，解析时间和日期类型
    def default(self, obj):
        if isinstance(obj, datetime.datetime):
            return obj.strftime('%Y-%m-%d %H:%M:%S')
        elif isinstance(obj, datetime.date):
            return obj.strftime("%Y-%m-%d")
        elif isinstance(obj, datetime.time):
            return obj.strftime("%H:%M:%S")
        else:
            return json.JSONEncoder.default(self, obj)

def display(request):  #photo.html的响应函数
    pid = []
    route = {}
    list = []
    for i in blacklist.objects.all():
        list.append([i.pid,i.path,i.location,i.date,i.time])
        if i.pid not in pid:
            pid.append(i.pid)
            temp = blacklist.objects.filter(pid = i.pid)
            temp_route = []
            for j in temp:
                temp_route.append(j.location)
            route.update({i.pid:temp_route})
     
    return render(request,'photo.html',{"List":json.dumps(list,cls=DateEncoder)})  #传递前端

def show(request):
    return render(request, 'index.html')

def GetPoints(request):
    fp = FP.FileProcess("coordinate.txt")
    response = JsonResponse(fp.Coordinate_pick())
    return response

def GetData(request):
    if request.is_ajax():
        dic = request.POST
    name = dic["name"]
    fp = FP.FileProcess("coordinate.txt")
    list = fp.Random_locinfo(200,300)
    content = "<nobr>当前地点人数:    %d</nobr><br><nobr>当前地点佩戴口罩的人数:    %d</nobr></br><nobr>当前地点口罩佩戴率:    %.2f</nobr>" % (list[name][0],list[name][1],list[name][2])
    response = JsonResponse({"name":content})
    return response

def GetHeat(request):
    fp = FP.FileProcess("coordinate.txt")
    # fp = FP.FileProcess("../coordinate.txt")
    dic1 = fp.Coordinate_pick()
    dic2 = fp.Random_locinfo(30,80)
    for i in dic1.keys():
        dic1[i].append(dic2[i][0])
    response = JsonResponse(dic1)
    return response

def GetRoute(request):
    if request.is_ajax():
        dic = request.POST
        print(dic)
    fp = FP.FileProcess("coordinate.txt")
    dic1 = fp.Coordinate_pick()
    #a = random.sample(dic1.keys(), 4)  # 随机一个字典中的key，第二个参数为限制个数
    Tlist = blacklist.objects.filter(pid = int(dic["name"]))
    a = []
    for i in Tlist:
        a.append(i.location)
    print(a)
    dic2 = {}
    for i in a:
        dic2[i] = dic1[i]
    # for i in a:
    #     dic2[i] = dic1[i]
    print(dic2)
    response = JsonResponse(dic2)
    return response

