import random
import numpy as np
from scipy.special import erfinv

class FileProcess:
    def __init__(self,filename):
        f = open(filename, 'r',encoding='utf8')
        self.content = [i.replace("\n","") for i in f]
        #print(self.content)
        f.close()
    def Coordinate_pick(self):
        coordinate_dic = {}
        i = 0
        while(i<len(self.content)-1):
            coordinate_dic[self.content[i]] = self.content[i+1].split(",")
            i+=3
        return coordinate_dic
    def Random_route(self,n): #参数n代表路线的节点个数
        coordinate_dic = self.Coordinate_pick()
        route = {}
        length = len(coordinate_dic)
        keys = list(coordinate_dic.keys())
        randlist = []
        for i in range(n):
            randlist.append(random.randint(0,length-1))
        for i in randlist:
            route[keys[i]] = coordinate_dic[keys[i]]
        return route
    def Random_locinfo(self,n,m):
        coordinate_dic = self.Coordinate_pick()
        locinfo = {}
        for i in coordinate_dic.keys():
            total = random.randint(n,m)
            r = random.uniform(0.8, 1)
            wear = total * r
            locinfo[i] = (total,wear,r)
        return locinfo

# a = FileProcess("../../coordinate.txt")
# print(a.Coordinate_pick())
