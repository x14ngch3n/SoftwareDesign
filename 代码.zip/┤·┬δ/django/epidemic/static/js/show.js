var arr = [ //模拟后台给的数据
    { name: "NO.1", src: "../static/image/1.jpg", des: "陈瑞球楼", sex: "m", age: 18 },
    { name: "NO.2", src: "../static/image/2.jpg", des: "东上院", sex: "m", age: 19 },
    { name: "NO.3", src: "../static/image/3.jpg", des: "凯原法学院", sex: "f", age: 17 },
    { name: "NO.4", src: "../static/image/4.jpg", des: "逸夫科技楼", sex: "f", age: 16 },
    { name: "NO.5", src: "../static/image/5.jpg", des: "图书馆", sex: "m", age: 20 }
];
var wra = document.getElementsByClassName("wra")[0];
var wb = wra.getElementsByClassName("wraBottom")[0];
var oUl = wb.getElementsByTagName("ul")[0];
var sex = document.getElementsByClassName('sex')[0];
var sexbtn = sex.getElementsByClassName("btn");
var inp = wra.getElementsByTagName("input")[0];

//创建全局默认值，记录每一次事件触发的数值
var state = {
    text: '',
    sex: 'a'
}

// 渲染页面
function renderPage(data) {
    oUl.innerHTML = "";
    data.forEach(function (ele, index, self) {
        //遍历数组里面的东西，取其中数据构建html结构，
        oUl.innerHTML += '<li><img src=' + ele.src + '><p class="name">' + ele.name + '</p><span>' + ele.age + '岁</span><p class="des">' + ele.des + '</p></li>';
    });
}
renderPage(arr);



//绑定性别点击事件
var lastDefault = sexbtn[2]; //默认性别选项All 
for(var i = 0; i < sexbtn.length; i++){
    (function(j){
        sexbtn[j].onclick = function(){
            sexbtn[j].className = "btn default";//点击时，给点击的按钮添加 css样式(default)
            lastDefault.className = "btn";// 赋给样式后，取消上一个btn的样式
            lastDefault = sexbtn[j];//赋给样式后，此次点击的btn 就成了过去

            state.sex = sexbtn[j].id;
            var newArr = screenSex(arr, state.sex); //筛选性别执行后返回新数组
            renderPage( screenInput(newArr, state.text));//利用新数组再次筛选搜索框，筛选后渲染页面
        }
    })(i)
}
// 筛选性别函数
function screenSex(data, sex) {
    if (sex == "a") { //判断输入的值是否为默认值a，如果是，不用筛选，直接返回原数组
        return data;
    } else {
        return data.filter(function (ele, index, self) {//利用数组方法filter过滤，不懂filter方法，请看本人另外笔记filter方法
            return sex == ele.sex; 
            //第一遍循环，查看 数组第一个数据里面的 sex 是否等于 传进来的sex  如果是，返回这条数据到新数组
            //{ name: "王小明", src: "./img/head.jpg", des: "成绩很好", sex: "m", age: 18 }  
        })
    }
}

//触发input事件
inp.oninput = function(){
    state.text = this.value;//记录当前输入的字
    var newArr = screenInput(arr, state.text);//筛选搜索框输入的值，执行后返回新数组
    renderPage( screenSex(newArr, state.sex));//利用新数组再次筛选性别，筛选后渲染页面
    
}
//筛选搜索框函数 
function screenInput(data, value){
    if(!value){//判断输入的值是否为默认值''，如果是，不用过滤，直接返回原数组
        return data;
    }else{
      return data.filter(function(ele, index, self){
           return ele.des.indexOf(value) >= 0; 
            //字符串方法，indexOf 查看value这个字符串，是否存在于ele.name中，如果存在返回大于0的索引(true)
            //如果不存在，返回-1，(false)
            //如果返回(true)，返回这条数据到新数组中
       })
    }
}