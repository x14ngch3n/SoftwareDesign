/**
 * Created by DELL on 2020/6/1.
 */
function GetData(id,name) {
    var formdata = new FormData();
    formdata.append("name",name);
    $.ajax({
        url: "/GetData",
        type: "post",
        data: formdata,
        contentType: false,
        processData: false,
        success: function (data) {
            document.getElementById(id).innerHTML = data["name"];
        },
        error: function (data) {
            document.getElementById(id).innerHTML = "获取信息失败，请重试！";
            console.log(data)
        }
    })
}

function refresh(id) {
    var formdata = new FormData();
    formdata.append("name",document.getElementById("title").innerHTML);
    $.ajax({
        url: "/GetData",
        type: "post",
        data: formdata,
        contentType: false,
        processData: false,
        success: function (data) {
            document.getElementById(id).innerHTML = data["name"];
        },
        error: function (data) {
            alert("刷新失败！");
            console.log(data)
        }
    })
}
