from django.db import models

# Create your models here.
class blacklist(models.Model):
    fid = models.AutoField(primary_key=True)
    pid = models.IntegerField()
    path = models.CharField(max_length=100)
    location = models.CharField(max_length=20)
    date = models.DateField()
    time = models.TimeField()

